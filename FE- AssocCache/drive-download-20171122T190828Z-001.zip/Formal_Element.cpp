// Formal_Element.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

struct cache_line
{
	unsigned char tag;
	bool valid_flag;
	bool lru_flag;
	char data[4];
} way0 [64], way1[64];
unsigned short cpuaddr;

int _tmain(int argc, _TCHAR* argv[])
{
	int hit0 =0;
	int hit1 =0;
	int miss =0;
	ifstream infile("cpu_addr.txt");
	for (int i=0; i<64; i++)
	{
		way0[i].valid_flag = 0;
		way1[i].valid_flag = 0;

		way0[i].lru_flag = 0;
		way1[i].lru_flag = 0;
	}

	string line;
	ifstream dram ("dram.txt");


	ifstream cpu_addr ("cpu_addr.txt");
	while(getline(cpu_addr, line)) {
		//cout<<line<<endl;
		int cpu_addr;
		istringstream(line) >> hex >> cpu_addr;
		//int cpu_addr = std::stoi (line,nullptr,16);
		//cout << cpu_addr<<endl;
		int uppaddr = cpu_addr & 0xff00;
		uppaddr >>= 8;
		//cout << "Uppaddr: "<< "0x"<<hex<< uppaddr << " " << bitset<16>(uppaddr).to_string()<<endl;
		int setno = cpu_addr & 0x00ff;
		setno >>= 2;
		//cout << "Setno: "<< setno << " " << bitset<16>(setno).to_string()<<endl<<"\n" ;

		if ((way0[setno].tag == uppaddr)&&(way0[setno].valid_flag==1))
		{
			cout << "HIT on way0, CPU address: "<< cpu_addr << ", Set no: "<<dec << setno<< ", Upper address:" << uppaddr<<endl;
			hit0++;
			way0[setno].lru_flag =1;
			way1[setno].lru_flag =0;
		}

		else if ((way1[setno].tag == uppaddr)&&(way1[setno].valid_flag=1))
		{
			cout << "HIT on way1, CPU address: "<< cpu_addr << ", Set no: "<<dec << setno<< ", Upper address:" << uppaddr<<endl;
			hit1++;
			way0[setno].lru_flag =0;
			way1[setno].lru_flag =1;
		}

		else
		{
			miss++;
			cout << "Miss, CPU address: "<< cpu_addr << ", Set no: "<<dec << setno<< ", Upper address:" << uppaddr<<endl;
			if (way0[setno].lru_flag == 0)
			{
				way0[setno].tag =uppaddr;
				way0[setno].lru_flag =1;
				way0[setno].valid_flag =1;
				cout << "Written to way0, CPU address: "<< cpu_addr << ", Set no: "<<dec << setno<< ", Upper address:" << uppaddr<<"\n"<<endl;

			}

			else if (way1[setno].lru_flag == 0)
			{
				way1[setno].tag =uppaddr;
				way1[setno].lru_flag =1;
				way1[setno].valid_flag =1;
				cout << "Written to way1, CPU address: "<< cpu_addr << ", Set no: "<<dec << setno<< ", Upper address:" << uppaddr<<"\n"<<endl;
				
			}
		}

    }
	/*int a,b;
	a=0x3333;
	b=0xff00;
	cout << bitset<16>(a & b).to_string() <<endl;
	*/
	cout <<"\n\nHits & Misses:"<<endl;
	cout << "Total HITS on way0:" << hit0<<endl;
	cout << "Total HITS on way1:" << hit1<<endl;
	cout << "Total misses:" <<dec<< miss<<endl;
	system("pause");
	return 0;
}

